# ApkT_installer

### Description
all pepole want to install apktool for hide virus in original android app, but in instalation have lot of broblems and hard for solve
and this script will make install apktool 2.9.0 with two click!!!

# Note ⚠️
+ the script need data connection or wifi for run and install requirements 
+ the script work on kali linux system 

## Tested on 
+ Kali Linux ✓


# Installation

### Kali linux 

```
sudo apt update -y
sudo apt upgrade -y
sudo apt install git wget python -y
git clone https://github.com/bad-boy2py/ApkT_installer.git
cd ApkT_installer
sudo chmod +x main.py
sudo python3 main.py 
```



# By Bad Boy 
